#!/usr/bin/python3
# -*- coding: utf-8 -*-
import requests
import json
import datetime
class updat():
    def __init__(self):
        self.dat=datetime.date.today()
        self.riqi=str(self.dat)
        self.di=[]
    def time_en(self):
        if self.riqi[8]!='0':
            self.riq=self.riqi[6]+'/'+self.riqi[8]+self.riqi[9]
        else:
            self.riq=self.riqi[6]+'/'+self.riqi[9]
    def get_dat(self):
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        url = "http://v.juhe.cn/todayOnhistory/queryEvent.php"
        params = {
            "key": "676c9cdb1f43759bf935b780d53a96b3",  # 在个人中心->我的数据,接口名称上方查看
            "date": self.riq,  # 日期,格式:月/日 如:1/1,/10/1,12/12 如月或者日小于10,前面无需加0
        }
        resp = requests.get(url,params,headers=headers)
        resp_json = json.loads(resp.text)
        for txt in resp_json['result']:
            self.di.append(txt['date']+":"+txt['title'])
    def gen_html(self):
        nt = F"""<!DOCTYPE html>
                <html>
                <head>
                <meta charset="utf-8">
                <title>www.history.hh</title>
                </head>
                <body background="photo.jpg" style="background-repeat:no-repeat; background-attachment:fixed;background-size:100% 100%;
                <span style="font-size: 50px;color:blue">历史上的今天</span><br>
                <span style="font-size: 30px;"> {self.dat}</span>
                <p>{self.di[0]}</p>
                <p>{self.di[1]}</p>
                <p>{self.di[2]}</p>
                <p>{self.di[3]}</p>
                <p>{self.di[4]}</p>
                <p>{self.di[5]}</p>
                <p>{self.di[6]}</p>
                <p>{self.di[7]}</p>
                <p>{self.di[8]}</p>
                <p>{self.di[9]}</p>
                <p>{self.di[10]}</p>
                
                <p>{self.di[11]}</p>
                <p>{self.di[12]}</p>
                <p>{self.di[13]}</p>
                <p>{self.di[14]}</p>
                <p>{self.di[15]}</p>
                <p>{self.di[16]}</p>
                <p>{self.di[17]}</p>
                <p>{self.di[18]}</p>
                <p>{self.di[19]}</p>
                <p>{self.di[20]}</p>
                <p>{self.di[21]}</p>
                </body>
            </html>"""
        with open('newtoday.html', 'w') as f:  # 历史上的今天
            f.write(nt)
if __name__=="__main__":
    t=updat()
    t.time_en()
    print(t.riqi)
    t.get_dat()
    t.gen_html()