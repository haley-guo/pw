import oo

def gen_home(new):
    nt = F"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>www.history.hh</title></head><body> <span style="font-size: 50px;color:blue">欢迎来到我的主页</span><span style="font-size: 30px;color:green">{new.dat}</span><br> <br><a href=http://192.168.0.128:7880/news style="font-size: 30px;color:green">今日新闻</a> <br><br><a href=http://192.168.0.128:7880/history style="font-size: 30px;color:green">历史上的今天</a> <br><br><a href=http://192.168.0.128:7880/up style="font-size: 30px;color:green">心灵鸡汤</a> <br><audio src="mu.mp3" autoplay loop></audio></body></html>"""
    with open('home.html', 'w') as f:
        f.write(nt)

if __name__=="__main__":
    n=oo.updat()
    gen_home(n)