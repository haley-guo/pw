import socket
import requests
import oo
import threading
import news
import zexue
import  homw

soup=[]
coo=''
def s_tcp():
    add=('',7880)
    tcp_s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    tcp_s.bind(add)
    tcp_s.listen(128)
    while True:
        global coo
        da,info=tcp_s.accept()
        dat=da.recv(1024).decode('utf-8')
        lines = dat.splitlines()
        print(lines[0])
        if 'new' in lines[0]:
            with open('newst.html','r') as f:
                 coo=f.read()
        if 'histo' in lines[0]:
            with open('newtoday.html','r') as f:
                 coo=f.read()
        if 'up' in lines[0]:
            with open('soupup.html','r') as f:
                 coo=f.read()
        if lines[0]=='GET / HTTP/1.1':
            with open('home.html','r') as f:
                 coo=f.read()
        #print(str(coo))
        headers='HTTP/1.1 200 OK\r\n'
        headers+='Connection :close\r\n'
        headers+='Content-Type:text/html;charset=utf-8\r\n'
        headers+='\r\n'
        c=coo
        cont=headers.encode("utf-8")+c.encode('utf-8')
        da.send(cont)
        da.close()
    tcp_s.close()

if __name__=="__main__":
    flag=1

    newsp=news.newes()
    new=oo.updat()
    sop=zexue.csoup()
    new.time_en()
    if flag:
        new.get_dat()
        newsp.get_news()
        sop.get_soup(soup)
        new.gen_html()
        newsp.gen_html(new)
        sop.gent_html(soup,new)
        flag=0
    homw.gen_home(new)
    s_tcp()
