import requests
import json
import oo
class newes():
    def __init__(self):
        self.story=[]
        self.urls=[]
        self.guonei=[]
        self.guoneiurl=[]
    def get_news(self):
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        url = "http://v.juhe.cn/toutiao/index"
        params = {
            "key": "自己的key",  # 在个人中心->我的数据,接口名称上方查看
            "type": "guoji",  # 类型：top(推荐,默认)；更多看请求参数说明
        }
        resp = requests.get(url, params, headers=headers)
        resp_json = json.loads(resp.text)
        for i in resp_json['result']['data']:
            self.story.append(i['title'])
            self.urls.append(i['url'])
            #print(i['title'],i['url'])
    def get_chnews(self):
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        url = "http://v.juhe.cn/toutiao/index"
        params = {
            "key": "7f0cc1dcf9b3d95fe330aa02a42cf11d",  # 在个人中心->我的数据,接口名称上方查看
            "type": "guonei",  # 类型：top(推荐,默认)；更多看请求参数说明
        }
        resp = requests.get(url, params, headers=headers)
        resp_json = json.loads(resp.text)
        for i in resp_json['result']['data']:
            self.guonei.append(i['title'])
            self.guoneiurl.append(i['url'])
            #print(i['title'],i['url'])
    def gen_html(self,new):
        nt = F"""<!DOCTYPE html>
         <html>
         <head>
         <meta charset="utf-8">
         <title>www.history.hh</title>
         </head>
         <body background="photo.jpg" style="background-repeat:no-repeat; background-attachment:fixed;background-size:100% 100%;"> 
            <span style="font-size: 50px;color:green">今日新闻</span><br>
            <span style="font-size: 30px;"> {new.dat}</span>
             <a href={self.urls[0]}>{self.story[0]}</a><br>
             <a href={self.urls[1]}>{self.story[1]}</a><br>
             <a href={self.urls[2]}>{self.story[2]}</a><br>
             <a href={self.urls[3]}>{self.story[3]}</a><br>
             <a href={self.urls[4]}>{self.story[4]}</a><br>
             <a href={self.urls[5]}>{self.story[5]}</a><br>
             <a href={self.urls[6]}>{self.story[6]}</a><br>
             <a href={self.urls[7]}>{self.story[7]}</a><br>
             <a href={self.urls[8]}>{self.story[8]}</a><br>
             <a href={self.urls[9]}>{self.story[9]}</a><br>
             <a href={self.urls[10]}>{self.story[10]}</a><br>
             <a href={self.urls[11]}>{self.story[11]}</a><br>
             <a href={self.urls[12]}>{self.story[12]}</a><br>         
             <a href={self.urls[13]}>{self.story[13]}</a><br>
             <a href={self.urls[14]}>{self.story[14]}</a><br>
             <a href={self.urls[15]}>{self.story[15]}</a><br>
             <a href={self.guoneiurl[0]}>{self.guonei[0]}</a><br>
             <a href={self.guoneiurl[1]}>{self.guonei[1]}</a><br>
             <a href={self.guoneiurl[2]}>{self.guonei[2]}</a><br>
             <a href={self.guoneiurl[3]}>{self.guonei[3]}</a><br>
             <a href={self.guoneiurl[4]}>{self.guonei[4]}</a><br>
             <a href={self.guoneiurl[5]}>{self.guonei[5]}</a><br>
             <a href={self.guoneiurl[6]}>{self.guonei[6]}</a><br>
             <a href={self.guoneiurl[7]}>{self.guonei[7]}</a><br>
             <a href={self.guoneiurl[8]}>{self.guonei[8]}</a><br>
             <a href={self.guoneiurl[9]}>{self.guonei[9]}</a><br>
             <a href={self.guoneiurl[10]}>{self.guonei[10]}</a><br>
             <a href={self.guoneiurl[11]}>{self.guonei[11]}</a><br>
             <a href={self.guoneiurl[12]}>{self.guonei[12]}</a><br>         
             <a href={self.guoneiurl[13]}>{self.guonei[13]}</a><br>
             <a href={self.guoneiurl[14]}>{self.guonei[14]}</a><br>
             <a href={self.guoneiurl[15]}>{self.guonei[15]}</a><br>
         </body>
         </html>"""
        with open('newst.html', 'w') as f:  # 写文件的今日的新闻
            f.write(nt)
if __name__=="__main__":
    c=newes()
    a=oo.updat()
    c.get_news()
    c.gen_html(a)

