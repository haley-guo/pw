#!/usr/bin/python3
# -*- coding: utf-8 -*-
import requests
import json
import  oo
soup=[]
class csoup():
    def get_soup(self,soup):
        for i in range(21):
            headers = {"Content-Type": "application/x-www-form-urlencoded"}
            url = "https://apis.juhe.cn/fapig/soup/query"
            params = {"key": "自己的key"}  # 在个人中心->我的数据,接口名称上方查看
            resp = requests.get(url, params, headers=headers)
            resp_json = json.loads(resp.text)
            c=resp_json['result']['text']
            soup.append(c)
    def gent_html(self,soup,new):
        nt = F"""<!DOCTYPE html>
                <html>
                <head>
                <meta charset="utf-8">
                <title>www.history.hh</title>
                </head>
                <body background="photo.jpg" style="background-repeat:no-repeat; background-attachment:fixed;background-size:100% 100%;
                <span style="font-size:50px;color:blue">心灵鸡汤</span><br>
                <span style="font-size:20px;"> {new.dat}</span>
                <p>{soup[0]}</p>
                <p>{soup[1]}</p>
                <p>{soup[2]}</p>
                <p>{soup[3]}</p>
                <p>{soup[4]}</p>
                <p>{soup[5]}</p>
                <p>{soup[6]}</p>
                <p>{soup[7]}</p>
                <p>{soup[8]}</p>
                <p>{soup[9]}</p>
                <p>{soup[10]}</p>
                <p>{soup[11]}</p>
                <p>{soup[12]}</p>
                <p>{soup[13]}</p>
                <p>{soup[14]}</p>
                <p>{soup[15]}</p>
                <p>{soup[16]}</p>
                <p>{soup[17]}</p>
                <p>{soup[18]}</p>
                <p>{soup[19]}</p>
                <p>{soup[20]}</p>
                </body>
            </html>"""
        with open('soupup.html', 'w') as f:  # 历史上的今天
            f.write(nt)
if __name__=="__main__":
    t=oo.updat()
    t.time_en()
    h=csoup()
    h.get_soup(soup)
    h.gent_html(soup,t)

